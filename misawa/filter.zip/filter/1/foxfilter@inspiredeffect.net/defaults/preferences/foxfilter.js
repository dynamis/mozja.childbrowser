pref("extensions.foxfilter@inspiredeffect.net.description", "chrome://foxfilter/locale/foxfilter.properties");
pref("FoxFilter.enabled", true);
pref("FoxFilter.whitelistEnabled", false);
pref("FoxFilter.email", "");
pref("FoxFilter.password", "");
pref("FoxFilter.passwordReminder", "");
pref("FoxFilter.keywords", "");
pref("FoxFilter.keywordPhrases", "");
pref("FoxFilter.urlExceptions", "mozilla.org");
pref("FoxFilter.examineUrl", true);
pref("FoxFilter.examineTitle", true);
pref("FoxFilter.examineMeta", true);
pref("FoxFilter.examineBody", false);
pref("FoxFilter.addonsEnabled", true);
pref("FoxFilter.aboutConfigEnabled", true);
pref("FoxFilter.loginSuccessful", false);


